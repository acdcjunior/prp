﻿var ngRange = function (top, bottom) {
    this.topRow = top;
    this.bottomRow = bottom;
};